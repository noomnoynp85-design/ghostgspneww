package com.ghostgps.app

import android.Manifest
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.os.Build
import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.ghostgps.app.databinding.ActivityMainBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import java.io.File
import java.util.Locale

class MainActivity : AppCompatActivity(), GhostState.Listener {

    private lateinit var b: ActivityMainBinding
    private lateinit var prefs: SharedPreferences

    private val points = ArrayList<GeoPoint>()
    private var ghost: Marker? = null
    private var routeMode = false

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    // real (non-mock) location
    private var realPoint: GeoPoint? = null
    private var realCancel: (() -> Unit)? = null
    private var fetchingReal = false
    private var pendingReal = false

    private val locPermission =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
            if (res.values.any { it }) onRealLocation()
            else toast("ต้องอนุญาตสิทธิ์ตำแหน่ง จึงจะดูตำแหน่งจริงได้")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initOsmdroid()
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        prefs = getSharedPreferences("ghostgps", MODE_PRIVATE)

        loadPoints()
        setupControls()
        setupMap()
        updateUi()

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onResume() {
        super.onResume()
        b.map.onResume()
        GhostState.listener = this
        if (!GhostState.running) removeGhost()
        updateUi()
        redraw()
        if (GhostState.running && !GhostState.lat.isNaN()) {
            moveGhost(GhostState.lat, GhostState.lng)
        }
    }

    override fun onPause() {
        pendingReal = false
        GhostState.listener = null
        b.map.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        realCancel?.invoke()
        realCancel = null
        b.map.onDetach()
        super.onDestroy()
    }

    // ---------- GhostState.Listener (called from the service thread) ----------

    override fun onPosition(lat: Double, lng: Double) {
        runOnUiThread { moveGhost(lat, lng) }
    }

    override fun onRunning(running: Boolean) {
        runOnUiThread {
            if (!running) removeGhost()
            updateUi()
            redraw()
            if (!running && pendingReal) {
                pendingReal = false
                fetchReal()
            }
        }
    }

    // ---------- setup ----------

    private fun initOsmdroid() {
        val cfg = Configuration.getInstance()
        cfg.userAgentValue = packageName
        val base = File(cacheDir, "osmdroid")
        base.mkdirs()
        val tiles = File(base, "tiles")
        tiles.mkdirs()
        cfg.osmdroidBasePath = base
        cfg.osmdroidTileCache = tiles
    }

    private fun setupMap() {
        val m = b.map
        m.setTileSource(TileSourceFactory.MAPNIK)
        m.setMultiTouchControls(true)
        m.zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
        if (points.isEmpty()) {
            m.controller.setZoom(12.0)
            m.controller.setCenter(GeoPoint(13.7563, 100.5018)) // Bangkok
        } else {
            m.controller.setZoom(15.0)
            m.controller.setCenter(points[0])
        }
        redraw()
    }

    private fun setupControls() {
        b.etInterval.setText(prefs.getString("interval", "10"))
        b.etSpeed.setText(prefs.getString("speed", "40"))
        b.swPingPong.isChecked = prefs.getBoolean("pingpong", false)
        routeMode = prefs.getBoolean("route", false)
        b.toggleMode.check(if (routeMode) R.id.btnRoute else R.id.btnJump)
        applyModeUi()

        b.toggleMode.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (isChecked) {
                routeMode = (checkedId == R.id.btnRoute)
                applyModeUi()
                redraw()
            }
        }
        b.swPingPong.setOnCheckedChangeListener { _, _ -> redraw() }

        b.btnUndo.setOnClickListener {
            if (points.isNotEmpty()) {
                points.removeAt(points.size - 1)
                savePoints()
                redraw()
            }
        }
        b.btnClear.setOnClickListener {
            if (points.isNotEmpty()) {
                MaterialAlertDialogBuilder(this)
                    .setMessage("ล้างจุดทั้งหมด ${points.size} จุด ?")
                    .setPositiveButton("ล้าง") { _, _ ->
                        points.clear()
                        savePoints()
                        redraw()
                    }
                    .setNegativeButton("ยกเลิก", null)
                    .show()
            }
        }
        b.btnStart.setOnClickListener { onStartStop() }
        b.btnReal.setOnClickListener { onRealLocation() }
    }

    private fun applyModeUi() {
        b.rowJump.visibility = if (routeMode) android.view.View.GONE else android.view.View.VISIBLE
        b.rowRoute.visibility = if (routeMode) android.view.View.VISIBLE else android.view.View.GONE
    }

    // ---------- start / stop ----------

    private fun readNumber(et: EditText): Double? =
        et.text.toString().trim().replace(',', '.').toDoubleOrNull()

    private fun onStartStop() {
        if (GhostState.running) {
            startService(Intent(this, GhostService::class.java).setAction(GhostService.ACTION_STOP))
            return
        }
        if (points.isEmpty()) {
            toast("แตะบนแผนที่เพื่อปักจุดอย่างน้อย 1 จุด")
            return
        }
        val interval = readNumber(b.etInterval)
        val speed = readNumber(b.etSpeed)
        if (routeMode) {
            if (points.size < 2) {
                toast("โหมดเส้นทางต้องมีอย่างน้อย 2 จุด")
                return
            }
            if (speed == null || speed <= 0.0) {
                toast("ใส่ความเร็ว (กม./ชม.) ให้ถูกต้อง")
                return
            }
        } else if (points.size >= 2 && (interval == null || interval < 1.0)) {
            toast("ใส่เวลาเป็นวินาที (อย่างน้อย 1)")
            return
        }
        saveSettings()

        if (!MockHelper.canMock(this)) {
            showLsposedHelp()
            return
        }

        val arr = DoubleArray(points.size * 2)
        for (i in points.indices) {
            arr[2 * i] = points[i].latitude
            arr[2 * i + 1] = points[i].longitude
        }
        val intent = Intent(this, GhostService::class.java).apply {
            action = GhostService.ACTION_START
            putExtra(GhostService.EXTRA_POINTS, arr)
            putExtra(GhostService.EXTRA_ROUTE, routeMode)
            putExtra(GhostService.EXTRA_INTERVAL_S, interval ?: 10.0)
            putExtra(GhostService.EXTRA_SPEED_KMH, speed ?: 0.0)
            putExtra(GhostService.EXTRA_PINGPONG, b.swPingPong.isChecked)
        }
        ContextCompat.startForegroundService(this, intent)
    }

    /**
     * The only way this app gets the mock-location permission is the LSPosed module
     * (MainHook, scope = System Framework). When the module is active, the normal mock check
     * (MockHelper.canMock) simply succeeds.
     */
    private fun showLsposedHelp() {
        MaterialAlertDialogBuilder(this)
            .setTitle("ต้องเปิดโมดูล LSPosed")
            .setMessage(
                "แอปนี้ยังไม่ได้สิทธิ์ Mock Location ผ่าน LSPosed ทำตามนี้ครั้งเดียว:\n\n" +
                    "1. เปิดแอป LSPosed > โมดูล > Ghost GPS > เปิดใช้งานโมดูล\n" +
                    "2. ในขอบเขต (Scope) ติ๊ก \"System Framework\" (android)\n" +
                    "3. รีบูตเครื่อง\n" +
                    "4. เปิดแอปนี้แล้วกด \"เริ่ม\" ใหม่"
            )
            .setPositiveButton("ตรวจสอบอีกครั้ง") { _, _ -> recheckLsposed() }
            .setNegativeButton("ปิด", null)
            .show()
    }

    private fun recheckLsposed() {
        Thread {
            val ok = MockHelper.canMock(this)
            runOnUiThread {
                if (ok) toast("ได้รับสิทธิ์แล้ว กด \"เริ่ม\" ได้เลย") else showLsposedHelp()
            }
        }.start()
    }

    // ---------- real location ----------

    private fun onRealLocation() {
        if (fetchingReal) return
        if (realPoint != null) { // second tap hides the real-location marker
            realPoint = null
            redraw()
            updateRealButton()
            return
        }
        if (!RealLocation.hasPermission(this)) {
            locPermission.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
            return
        }
        if (GhostState.running) {
            MaterialAlertDialogBuilder(this)
                .setTitle("กำลังปลอมพิกัดอยู่")
                .setMessage(
                    "ขณะปลอมพิกัด ระบบจะได้แต่ตำแหน่งปลอม จึงอ่านตำแหน่งจริงไม่ได้\n\n" +
                        "ต้องหยุดการปลอมก่อน แล้วแอปจะอ่านตำแหน่งจริงให้ (กด \"เริ่ม\" ใหม่ได้ภายหลัง)"
                )
                .setPositiveButton("หยุดแล้วดูตำแหน่งจริง") { _, _ ->
                    pendingReal = true
                    startService(
                        Intent(this, GhostService::class.java).setAction(GhostService.ACTION_STOP)
                    )
                }
                .setNegativeButton("ยกเลิก", null)
                .show()
            return
        }
        fetchReal()
    }

    private fun fetchReal() {
        fetchingReal = true
        updateRealButton()
        toast("กำลังหาตำแหน่งจริง… (ในอาคารอาจใช้เวลานานหน่อย)")
        realCancel = RealLocation.request(this) { loc ->
            realCancel = null
            fetchingReal = false
            if (loc == null) {
                toast(
                    "หาตำแหน่งจริงไม่ได้ ตรวจว่าเปิด \"ตำแหน่ง\" (Location) ในเครื่องแล้ว " +
                        "และไม่มีแอปปลอมพิกัดอื่นทำงานอยู่"
                )
            } else {
                val gp = GeoPoint(loc.latitude, loc.longitude)
                realPoint = gp
                redraw()
                b.map.controller.animateTo(gp, maxOf(b.map.zoomLevelDouble, 16.0), 600L)
                toast(
                    String.format(
                        Locale.US, "ตำแหน่งจริง %.5f, %.5f (±%d ม.)",
                        loc.latitude, loc.longitude, loc.accuracy.toInt()
                    )
                )
            }
            updateRealButton()
        }
    }

    private fun updateRealButton() {
        b.btnReal.isEnabled = !fetchingReal
        b.btnReal.text = when {
            fetchingReal -> "กำลังหา…"
            realPoint != null -> "ซ่อนตำแหน่งจริง"
            else -> "ตำแหน่งจริง"
        }
    }

    private fun makeRealMarker(gp: GeoPoint): Marker {
        val m = Marker(b.map)
        m.position = gp
        m.icon = realIcon()
        m.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
        m.setOnMarkerClickListener { _, _ ->
            toast(
                String.format(
                    Locale.US, "ตำแหน่งจริง %.5f, %.5f", gp.latitude, gp.longitude
                )
            )
            true
        }
        return m
    }

    private fun realIcon(): BitmapDrawable {
        val d = resources.displayMetrics.density
        val size = (30 * d).toInt()
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = 0x552F80ED
        c.drawCircle(size / 2f, size / 2f, size / 2f, p)
        p.color = 0xFFFFFFFF.toInt()
        c.drawCircle(size / 2f, size / 2f, 9 * d, p)
        p.color = 0xFF2F80ED.toInt()
        c.drawCircle(size / 2f, size / 2f, 6.5f * d, p)
        return BitmapDrawable(resources, bmp)
    }

    // ---------- map drawing ----------

    private fun onMapTap(p: GeoPoint) {
        if (GhostState.running) {
            toast("หยุดก่อนจึงจะแก้ไขจุดได้")
            return
        }
        points.add(GeoPoint(p.latitude, p.longitude))
        savePoints()
        redraw()
    }

    private fun redraw() {
        val m = b.map
        m.overlays.clear()
        m.overlays.add(MapEventsOverlay(object : MapEventsReceiver {
            override fun singleTapConfirmedHelper(p: GeoPoint): Boolean {
                onMapTap(p)
                return true
            }

            override fun longPressHelper(p: GeoPoint): Boolean = false
        }))

        if (routeMode && points.size >= 2) {
            val line = Polyline()
            val list = ArrayList<GeoPoint>(points)
            if (!b.swPingPong.isChecked) list.add(points[0])
            line.setPoints(list)
            line.outlinePaint.color = 0xCCB7A8FF.toInt()
            line.outlinePaint.strokeWidth = 8f
            m.overlays.add(line)
        }

        for (i in points.indices) {
            m.overlays.add(makeMarker(i, points[i]))
        }
        realPoint?.let { m.overlays.add(makeRealMarker(it)) }
        ghost?.let { m.overlays.add(it) }
        m.invalidate()
        updateInfo()
    }

    private fun makeMarker(index: Int, gp: GeoPoint): Marker {
        val m = Marker(b.map)
        m.position = gp
        m.icon = numberIcon(index + 1)
        m.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
        m.isDraggable = !GhostState.running
        m.setOnMarkerClickListener { _, _ ->
            if (GhostState.running) toast("หยุดก่อนจึงจะแก้ไขจุดได้") else confirmDelete(index)
            true
        }
        m.setOnMarkerDragListener(object : Marker.OnMarkerDragListener {
            override fun onMarkerDrag(marker: Marker?) {}

            override fun onMarkerDragEnd(marker: Marker?) {
                val p = marker?.position ?: return
                if (index < points.size) {
                    points[index] = GeoPoint(p.latitude, p.longitude)
                    savePoints()
                }
                b.map.post { redraw() }
            }

            override fun onMarkerDragStart(marker: Marker?) {}
        })
        return m
    }

    private fun confirmDelete(index: Int) {
        MaterialAlertDialogBuilder(this)
            .setMessage("ลบจุดที่ ${index + 1} ?")
            .setPositiveButton("ลบ") { _, _ ->
                if (index < points.size) {
                    points.removeAt(index)
                    savePoints()
                    redraw()
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun numberIcon(n: Int): BitmapDrawable {
        val d = resources.displayMetrics.density
        val size = (34 * d).toInt()
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = 0xFF1B1633.toInt()
        c.drawCircle(size / 2f, size / 2f, size / 2f, p)
        p.color = 0xFFB7A8FF.toInt()
        c.drawCircle(size / 2f, size / 2f, size / 2f - 2 * d, p)
        p.color = 0xFF1B1633.toInt()
        p.textAlign = Paint.Align.CENTER
        p.textSize = 16 * d
        p.typeface = Typeface.DEFAULT_BOLD
        c.drawText(n.toString(), size / 2f, size / 2f - (p.descent() + p.ascent()) / 2f, p)
        return BitmapDrawable(resources, bmp)
    }

    private fun moveGhost(lat: Double, lng: Double) {
        var g = ghost
        if (g == null) {
            g = Marker(b.map)
            g.icon = ContextCompat.getDrawable(this, R.drawable.ghost_marker)
            g.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
            g.setOnMarkerClickListener { _, _ -> true }
            ghost = g
            b.map.overlays.add(g)
        }
        g.position = GeoPoint(lat, lng)
        b.map.invalidate()
    }

    private fun removeGhost() {
        ghost?.let { b.map.overlays.remove(it) }
        ghost = null
    }

    // ---------- ui state ----------

    private fun updateUi() {
        val r = GhostState.running
        b.btnStart.text = if (r) "หยุด" else "เริ่ม"
        b.btnStart.backgroundTintList = ColorStateList.valueOf(
            ContextCompat.getColor(this, if (r) R.color.stop else R.color.primary)
        )
        val enabled = !r
        b.btnUndo.isEnabled = enabled
        b.btnClear.isEnabled = enabled
        b.btnJump.isEnabled = enabled
        b.btnRoute.isEnabled = enabled
        b.etInterval.isEnabled = enabled
        b.etSpeed.isEnabled = enabled
        b.swPingPong.isEnabled = enabled
        updateRealButton()
        updateInfo()
    }

    private fun updateInfo() {
        val sb = StringBuilder()
        sb.append("📍 ").append(points.size).append(" จุด")
        if (routeMode && points.size >= 2) {
            var d = 0.0
            for (i in 0 until points.size - 1) d += Geo.distance(pt(points[i]), pt(points[i + 1]))
            if (!b.swPingPong.isChecked) d += Geo.distance(pt(points[points.size - 1]), pt(points[0]))
            sb.append(" • ").append(String.format(Locale.US, "%.2f", d / 1000.0)).append(" กม.")
        }
        if (GhostState.running) sb.append(" • ▶ กำลังทำงาน")
        b.tvInfo.text = sb.toString()
    }

    private fun pt(g: GeoPoint) = Pt(g.latitude, g.longitude)

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // ---------- persistence ----------

    private fun loadPoints() {
        val raw = prefs.getString("points", "") ?: ""
        for (item in raw.split(";")) {
            val parts = item.split(",")
            if (parts.size != 2) continue
            val la = parts[0].toDoubleOrNull()
            val lo = parts[1].toDoubleOrNull()
            if (la != null && lo != null) points.add(GeoPoint(la, lo))
        }
    }

    private fun savePoints() {
        val s = points.joinToString(";") { "${it.latitude},${it.longitude}" }
        prefs.edit().putString("points", s).apply()
    }

    private fun saveSettings() {
        prefs.edit()
            .putString("interval", b.etInterval.text.toString())
            .putString("speed", b.etSpeed.text.toString())
            .putBoolean("pingpong", b.swPingPong.isChecked)
            .putBoolean("route", routeMode)
            .apply()
    }
}
