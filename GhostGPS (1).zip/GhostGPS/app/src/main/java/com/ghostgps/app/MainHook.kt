package com.ghostgps.app

import android.content.Context
import android.os.Binder
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import java.lang.reflect.Method

/**
 * LSPosed module entry point (listed in assets/xposed_init).
 *
 * Scope: "System Framework" (package "android"), reboot required after enabling.
 *
 * What it does: when the system checks the MOCK_LOCATION app-op, it answers "allowed" for this app
 * (com.ghostgps.app) and ONLY this app. This module is the app's only way to get the
 * mock-location permission (no root and no Developer options are used).
 *
 * Safety: every failure path returns false / does nothing, so a broken hook can never grant
 * anything. The caller's uid must really own the package name before the op is allowed.
 */
class MainHook : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName != "android") return
        try {
            hookMockLocationOp()
        } catch (t: Throwable) {
            XposedBridge.log("GhostGPS: hook failed: $t")
        }
    }

    private fun hookMockLocationOp() {
        val appOps = XposedHelpers.findClass("android.app.AppOpsManager", null)
        val mockCode = try {
            XposedHelpers.getStaticIntField(appOps, "OP_MOCK_LOCATION")
        } catch (t: Throwable) {
            58
        }

        val hook = object : XC_MethodHook() {
            override fun beforeHookedMethod(param: XC_MethodHook.MethodHookParam) {
                try {
                    if (shouldAllow(param, mockCode)) param.result = MODE_ALLOWED
                } catch (ignored: Throwable) {
                }
            }
        }

        var count = 0
        for (name in OP_METHODS) {
            count += XposedBridge.hookAllMethods(appOps, name, hook).size
        }
        XposedBridge.log("GhostGPS: hooked $count AppOpsManager methods")
    }

    /** args are (op, uid, packageName, ...) in every Android version we hook. */
    private fun shouldAllow(param: XC_MethodHook.MethodHookParam, mockCode: Int): Boolean {
        val a = param.args
        if (a == null || a.size < 3) return false

        val isMockOp = when (val op = a[0]) {
            is Int -> op == mockCode
            is String -> op == MOCK_OP_NAME
            else -> false
        }
        if (!isMockOp) return false

        val uid = a[1] as? Int ?: return false
        val pkg = a[2] as? String ?: return false
        if (pkg != OWN_PACKAGE) return false

        // only replace methods that return an int mode
        val m = param.method as? Method ?: return false
        if (m.returnType != Int::class.javaPrimitiveType) return false

        return uidOwnsPackage(uid, pkg)
    }

    private fun uidOwnsPackage(uid: Int, pkg: String): Boolean {
        if (busy.get() == true) return false
        busy.set(true)
        val token = Binder.clearCallingIdentity()
        try {
            val at = XposedHelpers.callStaticMethod(
                XposedHelpers.findClass("android.app.ActivityThread", null),
                "currentActivityThread"
            ) ?: return false
            val ctx = XposedHelpers.callMethod(at, "getSystemContext") as? Context ?: return false
            val owners = ctx.packageManager.getPackagesForUid(uid) ?: return false
            return owners.contains(pkg)
        } catch (t: Throwable) {
            return false
        } finally {
            Binder.restoreCallingIdentity(token)
            busy.set(false)
        }
    }

    private companion object {
        const val OWN_PACKAGE = "com.ghostgps.app"
        const val MOCK_OP_NAME = "android:mock_location"
        const val MODE_ALLOWED = 0

        val OP_METHODS = arrayOf(
            "noteOp", "noteOpNoThrow",
            "checkOp", "checkOpNoThrow",
            "unsafeCheckOp", "unsafeCheckOpNoThrow",
            "unsafeCheckOpRaw", "unsafeCheckOpRawNoThrow"
        )

        val busy = ThreadLocal<Boolean>()
    }
}
