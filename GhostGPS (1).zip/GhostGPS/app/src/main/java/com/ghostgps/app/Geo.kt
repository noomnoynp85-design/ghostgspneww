package com.ghostgps.app

import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

data class Pt(val lat: Double, val lng: Double)

class Fix(val pt: Pt, val bearing: Double)

object Geo {
    private const val R = 6371008.8

    fun distance(a: Pt, b: Pt): Double {
        val p1 = Math.toRadians(a.lat)
        val p2 = Math.toRadians(b.lat)
        val dp = p2 - p1
        val dl = Math.toRadians(b.lng - a.lng)
        val h = sin(dp / 2).pow(2) + cos(p1) * cos(p2) * sin(dl / 2).pow(2)
        return 2 * R * asin(min(1.0, sqrt(h)))
    }

    fun bearing(a: Pt, b: Pt): Double {
        val p1 = Math.toRadians(a.lat)
        val p2 = Math.toRadians(b.lat)
        val dl = Math.toRadians(b.lng - a.lng)
        val y = sin(dl) * cos(p2)
        val x = cos(p1) * sin(p2) - sin(p1) * cos(p2) * cos(dl)
        return (Math.toDegrees(atan2(y, x)) + 360.0) % 360.0
    }

    /** Point reached after moving [meters] from [a] along initial [bearingDeg] (great circle). */
    fun move(a: Pt, bearingDeg: Double, meters: Double): Pt {
        val d = meters / R
        val br = Math.toRadians(bearingDeg)
        val p1 = Math.toRadians(a.lat)
        val l1 = Math.toRadians(a.lng)
        val p2 = asin(sin(p1) * cos(d) + cos(p1) * sin(d) * cos(br))
        val l2 = l1 + atan2(sin(br) * sin(d) * cos(p1), cos(d) - sin(p1) * sin(p2))
        return Pt(Math.toDegrees(p2), ((Math.toDegrees(l2) + 540.0) % 360.0) - 180.0)
    }
}

/**
 * Walks along the path made by the user's points.
 * pingPong = false -> closed loop (last point connects back to the first)
 * pingPong = true  -> A -> B -> C -> B -> A -> ...
 */
class PathWalker(points: List<Pt>, private val pingPong: Boolean) {
    private val nodes: List<Pt> = if (pingPong) points else points + points.first()
    private val cum = DoubleArray(nodes.size)
    val total: Double

    init {
        for (k in 1 until nodes.size) {
            cum[k] = cum[k - 1] + Geo.distance(nodes[k - 1], nodes[k])
        }
        total = cum[nodes.size - 1]
    }

    /** Position after having travelled [s] meters in total since the start. */
    fun at(s: Double): Fix {
        if (total < 0.01) return Fix(nodes[0], 0.0)

        var d: Double
        var back = false
        if (pingPong) {
            d = s % (2 * total)
            if (d > total) {
                d = 2 * total - d
                back = true
            }
        } else {
            d = s % total
        }

        var i = 0
        while (i < nodes.size - 2 && cum[i + 1] < d) i++

        val a = nodes[i]
        val b = nodes[i + 1]
        val segLen = cum[i + 1] - cum[i]
        val brg = Geo.bearing(a, b)
        val off = (d - cum[i]).coerceIn(0.0, segLen)
        val p = if (segLen < 0.01) a else Geo.move(a, brg, off)
        val heading = if (back) (brg + 180.0) % 360.0 else brg
        return Fix(p, heading)
    }
}
