package com.ghostgps.app

/** Tiny in-process bridge between GhostService and MainActivity. */
object GhostState {

    interface Listener {
        fun onPosition(lat: Double, lng: Double)
        fun onRunning(running: Boolean)
    }

    @Volatile
    var running = false
        private set

    @Volatile
    var lat = Double.NaN
        private set

    @Volatile
    var lng = Double.NaN
        private set

    @Volatile
    var listener: Listener? = null

    fun setRunning(value: Boolean) {
        running = value
        if (!value) {
            lat = Double.NaN
            lng = Double.NaN
        }
        listener?.onRunning(value)
    }

    fun position(la: Double, lo: Double) {
        lat = la
        lng = lo
        listener?.onPosition(la, lo)
    }
}
