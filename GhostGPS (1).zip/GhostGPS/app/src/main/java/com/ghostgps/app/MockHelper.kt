package com.ghostgps.app

import android.content.Context
import android.location.Criteria
import android.location.LocationManager

object MockHelper {

    /**
     * True when this app is allowed to create a mock (test) location provider.
     * The permission comes only from the LSPosed module (see MainHook).
     */
    @Suppress("DEPRECATION")
    fun canMock(ctx: Context): Boolean {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val name = LocationManager.GPS_PROVIDER
        return try {
            try {
                lm.removeTestProvider(name)
            } catch (ignored: Exception) {
            }
            lm.addTestProvider(
                name, false, false, false, false, true, true, true,
                Criteria.POWER_LOW, Criteria.ACCURACY_FINE
            )
            try {
                lm.removeTestProvider(name)
            } catch (ignored: Exception) {
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}
