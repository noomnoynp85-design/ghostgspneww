package com.ghostgps.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Criteria
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.util.Log
import android.widget.Toast
import androidx.core.app.NotificationCompat

class GhostService : Service() {

    companion object {
        const val ACTION_START = "com.ghostgps.app.START"
        const val ACTION_STOP = "com.ghostgps.app.STOP"
        const val EXTRA_POINTS = "points"
        const val EXTRA_ROUTE = "route"
        const val EXTRA_INTERVAL_S = "interval_s"
        const val EXTRA_SPEED_KMH = "speed_kmh"
        const val EXTRA_PINGPONG = "pingpong"
        private const val CHANNEL_ID = "ghost_gps_run"
        private const val NOTIF_ID = 1
        private const val TAG = "GhostGPS"
    }

    private lateinit var lm: LocationManager
    private val providers = arrayOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)

    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var wake: PowerManager.WakeLock? = null
    @Volatile
    private var active = false

    // configuration of the current run
    private var route = false
    private var pts: List<Pt> = emptyList()
    private var intervalMs = 10_000L
    private var speedMps = 0.0
    private var walker: PathWalker? = null

    // state of the current run
    private var started = false
    private var idx = 0
    private var nextSwitch = 0L
    private var nextTick = 0L
    private var lastTick = 0L
    private var traveled = 0.0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (intent != null && action == ACTION_START) {
            start(intent)
        } else if (action == ACTION_STOP) {
            shutdown()
        } else {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun start(i: Intent) {
        ensureChannel()
        goForeground()
        cleanupRun()

        val arr = i.getDoubleArrayExtra(EXTRA_POINTS) ?: DoubleArray(0)
        val list = ArrayList<Pt>()
        var k = 0
        while (k + 1 < arr.size) {
            list.add(Pt(arr[k], arr[k + 1]))
            k += 2
        }
        if (list.isEmpty()) {
            shutdown()
            return
        }

        pts = list
        route = i.getBooleanExtra(EXTRA_ROUTE, false) && list.size >= 2
        intervalMs = (i.getDoubleExtra(EXTRA_INTERVAL_S, 10.0).coerceAtLeast(1.0) * 1000.0).toLong()
        speedMps = i.getDoubleExtra(EXTRA_SPEED_KMH, 0.0).coerceAtLeast(0.0) / 3.6
        walker = if (route) PathWalker(list, i.getBooleanExtra(EXTRA_PINGPONG, false)) else null

        if (!setupProviders()) {
            Handler(Looper.getMainLooper()).post {
                Toast.makeText(
                    applicationContext,
                    "ไม่ได้รับสิทธิ์ตำแหน่งจำลอง เปิดโมดูล LSPosed (ติ๊ก System Framework) แล้วรีบูต",
                    Toast.LENGTH_LONG
                ).show()
            }
            shutdown()
            return
        }

        started = false
        idx = 0
        traveled = 0.0

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GhostGPS:run").also { it.acquire() }

        active = true
        val t = HandlerThread("ghost-loop")
        t.start()
        thread = t
        val h = Handler(t.looper)
        handler = h
        nextTick = SystemClock.elapsedRealtime()
        h.post(loop)

        GhostState.setRunning(true)
    }

    private val loop = object : Runnable {
        override fun run() {
            if (!active) return
            try {
                step()
            } catch (e: Exception) {
                Log.w(TAG, "step failed", e)
            }
            val now = SystemClock.elapsedRealtime()
            nextTick += 1000
            if (nextTick <= now) nextTick = now + 1000
            handler?.postDelayed(this, nextTick - now)
        }
    }

    private fun step() {
        val now = SystemClock.elapsedRealtime()
        val w = walker
        if (route && w != null) {
            // Route mode: distance = speed x real elapsed time (exact km/h)
            if (!started) {
                started = true
                lastTick = now
                traveled = 0.0
            } else {
                traveled += speedMps * (now - lastTick) / 1000.0
                lastTick = now
            }
            val fix = w.at(traveled)
            publish(fix.pt, speedMps.toFloat(), fix.bearing.toFloat())
        } else {
            // Jump mode: hold a point, move to the next one every intervalMs
            if (!started) {
                started = true
                idx = 0
                nextSwitch = now + intervalMs
            } else if (pts.size > 1 && now >= nextSwitch - 50) {
                idx = (idx + 1) % pts.size
                nextSwitch += intervalMs
                if (nextSwitch <= now) nextSwitch = now + intervalMs
            }
            publish(pts[idx], 0f, 0f)
        }
    }

    private fun publish(p: Pt, speed: Float, bearing: Float) {
        val wallTime = System.currentTimeMillis()
        val elapsed = SystemClock.elapsedRealtimeNanos()
        for (name in providers) {
            val l = Location(name)
            l.latitude = p.lat
            l.longitude = p.lng
            l.altitude = 0.0
            l.accuracy = 3f
            l.speed = speed
            l.bearing = bearing
            l.time = wallTime
            l.elapsedRealtimeNanos = elapsed
            l.verticalAccuracyMeters = 3f
            l.speedAccuracyMetersPerSecond = 0.5f
            l.bearingAccuracyDegrees = 5f
            try {
                lm.setTestProviderLocation(name, l)
            } catch (e: Exception) {
                Log.w(TAG, "setTestProviderLocation($name) failed", e)
            }
        }
        GhostState.position(p.lat, p.lng)
    }

    @Suppress("DEPRECATION")
    private fun setupProviders(): Boolean {
        var gpsOk = false
        for (name in providers) {
            try {
                try {
                    lm.removeTestProvider(name)
                } catch (ignored: Exception) {
                }
                lm.addTestProvider(
                    name, false, false, false, false, true, true, true,
                    Criteria.POWER_LOW, Criteria.ACCURACY_FINE
                )
                lm.setTestProviderEnabled(name, true)
                if (name == LocationManager.GPS_PROVIDER) gpsOk = true
            } catch (e: Exception) {
                Log.w(TAG, "provider $name failed", e)
            }
        }
        return gpsOk
    }

    private fun teardownProviders() {
        for (name in providers) {
            try {
                lm.setTestProviderEnabled(name, false)
            } catch (ignored: Exception) {
            }
            try {
                lm.removeTestProvider(name)
            } catch (ignored: Exception) {
            }
        }
    }

    private fun cleanupRun() {
        active = false
        handler?.removeCallbacksAndMessages(null)
        thread?.quitSafely()
        thread = null
        handler = null
        wake?.let { if (it.isHeld) it.release() }
        wake = null
    }

    private fun shutdown() {
        cleanupRun()
        teardownProviders()
        GhostState.setRunning(false)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        cleanupRun()
        teardownProviders()
        GhostState.setRunning(false)
        super.onDestroy()
    }

    // ---------- notification ----------

    private fun ensureChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Ghost GPS", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun goForeground() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun buildNotification(): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), flags)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, GhostService::class.java).setAction(ACTION_STOP), flags
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_ghost)
            .setContentTitle("Ghost GPS")
            .setContentText("กำลังจำลองตำแหน่ง")
            .setContentIntent(open)
            .addAction(0, "หยุด", stop)
            .setOngoing(true)
            .build()
    }
}
