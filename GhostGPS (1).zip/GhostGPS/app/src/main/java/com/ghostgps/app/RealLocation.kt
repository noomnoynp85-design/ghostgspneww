package com.ghostgps.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat

/**
 * Reads the device's REAL position (never a mock one).
 *
 * Note: while Ghost GPS is running it replaces the GPS and network providers with test
 * providers, so a real fix is only possible after the mock has been stopped.
 * Every fix flagged as "mock" is ignored, so a leftover fake position is never shown as real.
 */
object RealLocation {

    fun hasPermission(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    @Suppress("DEPRECATION")
    private fun isMocked(l: Location): Boolean =
        if (Build.VERSION.SDK_INT >= 31) l.isMock else l.isFromMockProvider

    /**
     * Waits for the first non-mock fix from GPS or network.
     * Calls [onDone] on the main thread with the fix, or null on timeout / failure.
     * Returns a function that cancels the request.
     */
    @SuppressLint("MissingPermission")
    fun request(
        ctx: Context,
        timeoutMs: Long = 25_000L,
        onDone: (Location?) -> Unit
    ): () -> Unit {
        val lm = ctx.applicationContext.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val main = Handler(Looper.getMainLooper())
        val listeners = ArrayList<LocationListener>()
        var finished = false
        lateinit var timeout: Runnable

        fun cleanup() {
            for (l in listeners) {
                try {
                    lm.removeUpdates(l)
                } catch (ignored: Exception) {
                }
            }
            listeners.clear()
        }

        fun finish(loc: Location?) {
            if (finished) return
            finished = true
            main.removeCallbacks(timeout)
            cleanup()
            onDone(loc)
        }

        timeout = Runnable { finish(null) }

        var registered = 0
        for (name in arrayOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
            try {
                if (!lm.isProviderEnabled(name)) continue
                val listener = object : LocationListener {
                    override fun onLocationChanged(location: Location) {
                        if (!isMocked(location)) finish(location)
                    }

                    override fun onProviderEnabled(provider: String) {}

                    override fun onProviderDisabled(provider: String) {}

                    // Required on Android 8-9 (abstract there, default method on 10+).
                    @Suppress("OVERRIDE_DEPRECATION")
                    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                }
                lm.requestLocationUpdates(name, 0L, 0f, listener, Looper.getMainLooper())
                listeners.add(listener)
                registered++
            } catch (ignored: Exception) {
            }
        }

        if (registered == 0) {
            main.post { finish(null) }
        } else {
            main.postDelayed(timeout, timeoutMs)
        }

        return {
            if (!finished) {
                finished = true
                main.removeCallbacks(timeout)
                cleanup()
            }
        }
    }
}
